# Project KEYSTONE — Field Service Management Platform

Built for Meridian Facilities Management. Spring Boot 3 (Java 21) backend, React +
TypeScript frontend, PostgreSQL with Flyway migrations, stateless JWT auth with
four roles (dispatcher, technician, manager, customer).

## What's implemented

- **Auth & RBAC (F1)** — JWT login, four roles, BCrypt passwords, server-side
  `@PreAuthorize` checks on every protected endpoint.
- **Customers & sites (F2)** — CRUD for customers/sites; a site always belongs to
  a customer; server-side scoping so customers only see their own org's data.
- **Work-order management (F3)** — create/list/fetch with validation and a
  unique human-readable code (`WO-2026-0001`).
- **Dispatch & assignment (F4)** — assign to a technician; a Kanban board by status.
- **Technician field view (F5)** — "My jobs", start/hold/complete, log time.
- **Parts & time logging (F6)** — logging parts decrements stock in the *same*
  transaction; stock can't go negative.
- **Work-order lifecycle (Section 07)** — guarded state machine enforced in
  `WorkOrderService`, not the UI. Illegal transitions return `409`. Every
  transition writes an append-only `WorkOrderStatusHistory` row.
- **SLA tracking (F7)** — SLA due date set from priority on creation; a
  `@Scheduled` job (`SlaBreachChecker`, runs every 5 min) flags orders that
  pass their due date and logs a breach notification hook; the board and
  dashboard both surface `slaBreached`.
- **Dashboard (F8)** — status counts, overdue count, SLA compliance %, plus
  breakdowns of open jobs by technician and by site.
- **Customer portal (F9)** — customers raise requests and see only their own
  work orders and status history; `customerId` comes from the JWT/login
  response, not a hardcoded value.
- **User lookup (`GET /api/users?role=`)** — dispatchers/managers can list
  technicians for the assignment picker (never exposes password hashes).
- **Board filters** — search by title/code/site and filter by priority.
- **Tests** — `WorkOrderServiceTest` (JUnit 5 + Mockito) covers the guarded
  lifecycle (illegal transitions rejected, terminal states can't move),
  role-based authorization (only a manager can CLOSE, only the assigned
  technician can start/hold/complete their own job), transactional part/stock
  integrity (insufficient stock rejected, stock unchanged on failure), and
  data integrity on create (site must belong to the given customer). This is
  the highest-value testing target per the brief's own Section 16.1 —
  extend it with controller-level `@WebMvcTest` / `@SpringBootTest` +
  Spring Security Test cases next if you want end-to-end HTTP coverage.
- **API docs** — springdoc-openapi / Swagger UI at `/swagger-ui.html`.

### What's still intentionally left out (stretch territory, not core scope)

- Photo/attachment upload for technicians.
- Real-time notifications (email/in-app) on the SLA breach hook — currently
  logs a structured warning; wiring an actual channel is a small addition
  once you pick one (see the comment in `SlaBreachChecker`).
- Reassignment-while-open works via the same `/assign` endpoint but the UI
  doesn't yet expose a "reassign" affordance distinct from the initial assign.
- Full list/filter/search/pagination controls on every list view — the board
  has search + priority filter; customer portal and My Jobs are unfiltered
  lists (the APIs support `?page=&size=&sort=` already).

These are reasonable candidates for the stretch goals in Section 13.1 of the
brief, or for polish time in Week 4 — the core M1–M3 scope (auth, lifecycle,
dispatch, parts/time, SLA) is now fully implemented and tested.

## Local setup

**Prerequisites:** Docker + Docker Compose (simplest), or Java 21 + Maven +
Node 20 + PostgreSQL 16 installed locally.

### Option A — Docker Compose (recommended)

```bash
docker compose up --build
```

- Backend: http://localhost:8080 (Swagger at `/swagger-ui.html`)
- Frontend: http://localhost:5173
- Postgres: localhost:5432 (db `keystone`, user/pass `keystone`/`keystone`)

Flyway runs the migrations and seed data automatically on backend startup.

### Option B — run backend and frontend separately

```bash
# 1. Start Postgres (or point DATABASE_URL at any Postgres 14+ instance)
docker run -d --name keystone-db -e POSTGRES_DB=keystone \
  -e POSTGRES_USER=keystone -e POSTGRES_PASSWORD=keystone \
  -p 5432:5432 postgres:16-alpine

# 2. Backend
cd backend
mvn spring-boot:run
# uses application.yml defaults pointing at localhost:5432

# 3. Frontend
cd frontend
cp .env.example .env   # VITE_API_BASE_URL=http://localhost:8080
npm install
npm run dev
```

### Seed logins

All seeded users share the password **`Password123!`**:

| Role       | Email                        |
|------------|-------------------------------|
| Dispatcher | dispatcher@keystone.demo      |
| Manager    | manager@keystone.demo         |
| Technician | technician@keystone.demo      |
| Technician | technician2@keystone.demo     |
| Customer   | customer@keystone.demo        |

## Architecture

```
frontend/   React + TypeScript (Vite) SPA — role-based routes and views
backend/    Spring Boot 3 layered service
  controller/  thin REST controllers, @PreAuthorize role checks
  service/     business rules — WorkOrderService owns the state machine
  repository/  Spring Data JPA
  domain/      JPA entities
  security/    JWT filter, Spring Security config
  db/migration/  Flyway SQL migrations (schema + seed)
```

Requests flow: React → REST controllers (auth + validation) → services
(business rules, `@Transactional` boundaries) → repositories → PostgreSQL.

## API reference

Full interactive docs at `/swagger-ui.html` once the backend is running.
Representative endpoints:

| Endpoint | Method | Notes |
|---|---|---|
| `/api/auth/login` | POST | Returns JWT + role |
| `/api/work-orders` | GET/POST | Role-scoped, paginated |
| `/api/work-orders/{id}/assign` | POST | Dispatcher/manager only |
| `/api/work-orders/{id}/status` | POST | Validated against the lifecycle; `409` on illegal jump |
| `/api/work-orders/{id}/parts` | POST | Transactional stock decrement |
| `/api/work-orders/{id}/time` | POST | Technician logs minutes |
| `/api/work-orders/reports/summary` | GET | Dashboard metrics |

## Deploying (Render)

See the step-by-step walkthrough in the chat response, or replicate with any
host that supports a Docker web service (Railway, Fly.io) plus a managed
Postgres instance — the `Dockerfile`s in `backend/` and `frontend/` and the
env vars documented above are all you need to adapt this to another platform.

## Environment variables

**Backend**
| Var | Purpose | Local default |
|---|---|---|
| `DATABASE_URL` | JDBC URL | `jdbc:postgresql://localhost:5432/keystone` |
| `DATABASE_USERNAME` / `DATABASE_PASSWORD` | DB creds | `keystone` / `keystone` |
| `JWT_SECRET` | HMAC signing key (32+ chars) | dev placeholder — **change for any real deployment** |
| `JWT_EXPIRATION_MS` | Token lifetime | `86400000` (24h) |
| `PORT` | Server port | `8080` |

**Frontend**
| Var | Purpose |
|---|---|
| `VITE_API_BASE_URL` | Base URL of the deployed backend |
